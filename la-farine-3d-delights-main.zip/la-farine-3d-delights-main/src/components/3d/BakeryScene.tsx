import { motion } from "framer-motion";

// Fallback 3D-like component when Spline scene is not available
export function BakeryScene() {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      {/* Animated Croissant Illustration */}
      <motion.div
        animate={{
          y: [0, -20, 0],
          rotate: [0, 5, 0, -5, 0],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="relative"
      >
        {/* Main croissant body */}
        <div className="relative w-64 h-40 md:w-80 md:h-52">
          {/* Croissant shape using gradients */}
          <div
            className="absolute inset-0 rounded-[50%] transform rotate-[-15deg]"
            style={{
              background: "linear-gradient(135deg, hsl(35 75% 65%) 0%, hsl(30 70% 50%) 50%, hsl(25 65% 40%) 100%)",
              boxShadow: "0 20px 50px -20px hsl(25 50% 30% / 0.4), inset 0 -10px 30px hsl(25 60% 35% / 0.3)",
            }}
          />
          {/* Layers */}
          <div
            className="absolute top-[20%] left-[10%] w-[80%] h-[15%] rounded-full opacity-40"
            style={{
              background: "linear-gradient(90deg, transparent 0%, hsl(35 80% 75%) 50%, transparent 100%)",
            }}
          />
          <div
            className="absolute top-[40%] left-[15%] w-[70%] h-[12%] rounded-full opacity-30"
            style={{
              background: "linear-gradient(90deg, transparent 0%, hsl(35 80% 75%) 50%, transparent 100%)",
            }}
          />
          <div
            className="absolute top-[55%] left-[20%] w-[60%] h-[10%] rounded-full opacity-25"
            style={{
              background: "linear-gradient(90deg, transparent 0%, hsl(35 80% 75%) 50%, transparent 100%)",
            }}
          />
        </div>

        {/* Floating particles */}
        <motion.div
          animate={{ y: [-10, 10, -10], opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 3, repeat: Infinity, delay: 0 }}
          className="absolute -top-4 -right-4 w-3 h-3 rounded-full bg-accent/40"
        />
        <motion.div
          animate={{ y: [10, -10, 10], opacity: [0.3, 0.8, 0.3] }}
          transition={{ duration: 4, repeat: Infinity, delay: 0.5 }}
          className="absolute top-1/2 -left-6 w-2 h-2 rounded-full bg-caramel/30"
        />
        <motion.div
          animate={{ y: [-5, 15, -5], opacity: [0.4, 0.9, 0.4] }}
          transition={{ duration: 3.5, repeat: Infinity, delay: 1 }}
          className="absolute -bottom-2 right-1/4 w-4 h-4 rounded-full bg-accent/20"
        />
      </motion.div>

      {/* Glow effect */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(circle at center, hsl(35 80% 55% / 0.15) 0%, transparent 60%)",
        }}
      />

      {/* Interaction hint */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-4 left-1/2 -translate-x-1/2 text-xs text-muted-foreground bg-card/80 backdrop-blur-sm px-3 py-1.5 rounded-full"
      >
        Freshly baked daily
      </motion.p>
    </div>
  );
}
